---
home: true
heroImage: /uagLogo.png
actionText: Start Reading
actionLink: /fundamentals/
---

> This handbook is designed to be used as a learning resource for all things UAG. You can find everything from basic information about the group to advanced leadership strategies and more! This handbook is a living document, and can change at any time, so be sure to check back occasionally.
