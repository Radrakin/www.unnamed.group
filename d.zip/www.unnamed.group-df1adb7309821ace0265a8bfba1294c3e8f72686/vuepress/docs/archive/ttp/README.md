# Tactics, Techniques, and Procedures

`...`
