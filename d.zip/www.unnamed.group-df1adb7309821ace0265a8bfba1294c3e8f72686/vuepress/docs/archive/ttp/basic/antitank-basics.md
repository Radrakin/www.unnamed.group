# Anti-Tank Basics

## 1. Introduction

Anti-Tank is pretty self explanatory: you counter tanks, or well anything with armor.

IMPORTANT!!! Your launchers have a backblast meaning anybody closely behind you will have his or her face melted off. Make sure people are clear from your backblast before firing. And check targets thx xx armadillo.

## 2. Light Anti-Tank

LAT (light anti-tank) is well light anti-tank. LAT most of the time is a preloaded launcher that cannot be reloaded. They cannot take on everything, but they can destroy light armor like
BTRs or technicals. Most of the time you will either have HEAT or HEDP and sometimes HE (high explosive which is to kill infantry). These rounds are almost identical. HEAT is a round that upon impact explodes and uses the hot gasses to cut through armor.
HEDP does the same but has a fragmentation head on it which allows you to use it against armor and infantry.

## 3. Medium Anti-Tank

MAT is the chad version of LAT because it has big rounds, longer ranges, you can reload it and most important of all it has cool names like the carl gustav. As I said earlier you can reload these bois making it so you don't have to stick to one ammo type the carl gustav can take HEAT and HE for example.
The RPG-7 has more rounds it has 4 that are somewhat important these are the PG-7VL a single-stage HEAT round, the PG-7VR a tandem charge HEAT round (tandem charge means it has 2 or more charges allowing you to cut through multiple layers of armor in this case it's 2 charges), the OG-7V is a fragmentation round for use against infantry, the TBG-7V is a thermobaric round which means it uses the oxygen in the air to generate a fuck ton of heat killing any capatalist pig and his friends in a 10 meter radius.

## 4. Heavy Anti-Tank

HAT is the biggest of boys with big rounds and long ranges of up bassicly how far you can lock your launcher from. They destroy anything. We'll go more in debt in the Anti-Tank Advanced chapter.

## 5. Armor

Guess what these boys have armor and you are anti armor but there isn't just one kind you've got multiple i'll be going over 3. First off just metal plates they're just plates use any anti tank round and you'll be fine. Next we have slat armor which is like a cage around the vehicle the cage is made to make HEAT rounds and other charge anti tank rounds explode before they reach the tank itself, bassically making them useless.
Last we will talk about ERA (explosive reactive armor) which looks like squares you'll know what it is when you see it, they are made out of 2 metal plates with an explosive charge inbetween them. when hit the explosive charge inbetween them will go off and cause the round to either deflect or lose a larg amount of energy.
And remember the weakest sides of a tank are the rear and the sides when firing at the sides make sure you're not hitting reactive armor unless you want to die.

## 6. Extra stuff and TL;DR

Take rangefinders and make sure you have different ammunitions when you're MAT or HAT.

Don's shoot HEAT at cages and try to not hit the square plates. LAT launchers are M136 RPG-18 M76LAW ILAW and some more. MAT is the RPG-7 MAAWS or Carl Gustav. HAT is the javelin or the titan.
