# Autorifleman Basics

## 1. Introduction

The role of an Autorifleman is a pretty simple thing to do. As an Autorifleman you surpress the enemy and cover your team.

## 2. The Difference Between Supressive fire and Cover fire.

Both covering fire and suppressive fire involves lobbing an extreme amount of bullets toward the enemies (Or at least the general direction of the enemies).

But covering fire is done when you’re trying to steer enemy’s fire away from something that you don’t want them to pockmark, for example: A medic conducting field first aid on a wounded personnel.

Suppressive fire, on the other hand, means that no one is needing cover: The only thing that you want to need cover is the enemies.

The idea is to make a storm of metal so intense that the enemies don’t even dare to even poke their head out of their covers, let alone returning fire. This will impede their motions and buy time for air support or more final solutions to finish them off, or to allow units to maneuver closer to them to get more of a fighting edge.

Suppressive fire is to prevent enemies from mobilising or to conduct their operations efficiently.

Both have to do with mobilisation and operating, which are all vital to a fight. A combat unit who can mobilise more freely and operating more efficiently will usually emerge victorious over opponents who are starved of the two things above.

### 2a. The different types of fire support

Basic rule of thumb for all types of fire support is to do three round burst every two seconds or so this will conserve your ammo and keep the enemy down while you perform your operations.

#### The Shoot and Scoot/ Leap Frog Method

The shoot and scoot method is used to gain teritory as one team split in half as an autorifleman you are the main supressor aim at the enemy and provide cover fire for the other half of your team to move up after they do they will do the same for you and so on.

#### The Tactical Retreat Method

When retreating try to keep eyes on the enemy and keep them pinned while making your way inbetween covers to your evac point.

#### The Get off my Lawn Method

Similar to a marksman you find a high postion that has eyes on a good majority of the battle field and keep the enemies surpressed to keep them from moving forward to your postion.

## 3. Equipment

### 3a. Your gun

Your gun is your most used tool its what goes shooty shooty bang bang. Your basic M249 weighs about 15 pounds so its a heavy boi. The M249 forms the basis of firepower for the fire team. The gunner has the option of using 30-round Stanag mags or 200-round mags. The M249's maximum effective range is around 1 klick but most of the time you will be within 500 meters.

### 3b. Bitch Boi

Your "_Bitch Boi_" is a basic rifleman that carries extra amunition for you. Protect this boi if he dies and you run out of ammo your fucked have fun.

### 3c. Uniform

As an autorifleman your already a heavy boi because of your gun and ammunition so go ahead and get a heavier vest and helmet. Aslong as your Light enough to be able to jog and have a short sprint your fine.

### 3d. Recomended Aditional Gear

#### SSWT Kit

Your SSWT Kit is a less taken piece of equipment but usefull. Its a foldable, raisable tripod to be placed as a base for your bipod to rest on.

#### Vector 21/ Vector 21 Nite

This is your Range bois when on a base of fire team you need to be able to find the distance to a target these allow you to do that by pressing and holding **R**.

## 4. TL;DR

You have big gun, make enemy scared, keep team safe.
