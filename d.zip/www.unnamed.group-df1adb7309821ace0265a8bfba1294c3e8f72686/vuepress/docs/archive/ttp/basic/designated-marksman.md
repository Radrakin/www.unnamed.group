# Designated Marksman

## 1. What is a Designated Marksman?

OwO What's this?? You want to use a big shooty gun?? weww bewow is aww you need to know on being a designated mwawksman.

Being a designated marksman means you will reside within the **base of fire** team.

## 2. Equipment

As a marksman we use marksman rifles. For the most part, your rifle choice is personal preference as most marksman rifles don't differ all too much. The below weapons are our standard rifles, these can be adapted or switched out depending on the preference:

| ***Common Use DMRs**|
| ---------------|
| Mk14 ERB       |
| Cyrus          |
| HK417          |
| M14 DMR        |

Additional equipment that we take is a 7400 Radio so that we can communicate with the section and our team. A range card, this will update for your equipped gun. A soflam to gain an accurate range. Depending on your weight a SSWT kit can be useful to allow you the ability to bipod your weapon anywhere. We could use things like a Kestral or Atrag for an extremely accurate zeroing, however this isn't needed most of the time for a designated marksman. We aren't commonly at a range where we need a more complex zeroing, as well as the time taken to do this won't always be available to you when attached to base of fire. Pressing **SHIFT + K** to get your wind direction/speed and checking the zeroing with the distance on a range card is usually fast and effective enough.


### 2a. Uniform

Light clothing and armour is preferable when moving as a marksman. Our ammunition tends to weigh more than the regular rifleman, so cutting back on other unessential pieces of equipment in your uniform is helpful.

## 3. Marksman in the field

The role of a marksman is very straight forward in OP. We move out with the rest of base of fire and support the assault team as they move in and clear objectives. Your job is to help keep them from being shot in the fucking face by someone while they rush in to the objective. Also to take out enemy marksmans and other targets of interest, like MG nests or enemy AT.
