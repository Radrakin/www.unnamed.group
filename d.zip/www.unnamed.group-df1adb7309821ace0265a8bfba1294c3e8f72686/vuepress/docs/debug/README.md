# Debug

<details>
  <summary><code>@/package.json</code></summary>

<<< @/package.json

</details>

<details>
  <summary><code>@/public-inject/badges.json</code></summary>

<<< @/public-inject/badges.json

</details>

<details>
  <summary><code>@/docs/.vuepress/config.js</code></summary>

<<< @/docs/.vuepress/config.js

</details>

<details>
  <summary><code>@/docs/.vuepress/darkreader.js</code></summary>

<<< @/docs/.vuepress/darkreader.js

</details>

<details>
  <summary><code>@/docs/.vuepress/styles/index.styl</code></summary>

<<< @/docs/.vuepress/styles/index.styl

</details>

<details>
  <summary><code>@/docs/.vuepress/styles/palette.styl</code></summary>

<<< @/docs/.vuepress/styles/palette.styl

</details>
