# About the Unit

## Introduction

Unnamed Arma Group is a military simulation group that doesn't engage in the drama-inducing and power-tripping bullshit that plagues every other group. We do not conform to any one doctrine, or try to play arm-chair veterans, we are simply just a bunch of friends who love playing Arma!

### Core Values

Our core values dictate how we run the unit and all of it's operations. From gameplay and leadership to mission making and conflict resolution, we strive to implement our core values wherever we can to ensure all members have a universally-great gameplay experience.

**Our core values are:**

1. Be respectful, but not pandering.
2. Be truthful, but not callous.
3. Be right, but not arrogant.
4. Be content, but not oblivious.
5. Be innovative, but not reckless.

We cannot stress just how important these core values are to the staff members running UAG. If, at any point, you find yourself or another member violating these core values, even if they're staff, please notify us as soon as possible. The maintenance of these values are what make UAG the best unit in the world, and only together can we continue to ensure that is the case for all who play with us.
