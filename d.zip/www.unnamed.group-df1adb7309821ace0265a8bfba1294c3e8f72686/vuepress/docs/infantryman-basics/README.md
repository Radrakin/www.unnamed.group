# Introduction

This chapter is intended to provide all of the necessary skills for you to become a valuable member of our infantry teams. We will be going over materials like using your weaponry effectively, considering your spacing, and the foundations of teamwork in the fireteam.
