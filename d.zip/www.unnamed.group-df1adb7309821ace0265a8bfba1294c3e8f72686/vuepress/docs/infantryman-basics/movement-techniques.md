# Movement Techniques

::: warning THIS DOCUMENT IS INCOMPLETE
This document is still being worked on by our staff team
:::

[[TOC]]

## Formations

### Wedge

[![](/handbook/formations/Wedge.jpg)](/handbook/formations/Wedge.jpg)

### Vee

[![](/handbook/formations/Vee.jpg)](/handbook/formations/Vee.jpg)

### Column

[![](/handbook/formations/Column.jpg)](/handbook/formations/Column.jpg)

### Staggered Column

[![](/handbook/formations/Staggered-Column.jpg)](/handbook/formations/Staggered-Column.jpg)

### Line

[![](/handbook/formations/Line.jpg)](/handbook/formations/Line.jpg)

### Baseline

[![](/handbook/formations/Baseline.jpg)](/handbook/formations/Baseline.jpg)

### File

[![](/handbook/formations/File.jpg)](/handbook/formations/File.jpg)

### Diamond

[![](/handbook/formations/Diamond.jpg)](/handbook/formations/Diamond.jpg)

### Echelon

[![](/handbook/formations/Echelon-R.jpg)](/handbook/formations/Echelon-R.jpg)
