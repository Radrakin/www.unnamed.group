# Orienteering

::: warning THIS DOCUMENT IS INCOMPLETE
This document is still being worked on by our staff team
:::

## Reading the Map

### Grids & Keypads

The grids on the map dictate standard-sized areas in the world. Grid locations can be determined by reading the axis like regular coordinates, starting with the X-axis (the bottom or top) then the Y-axis (the sides). Grid locations can also come in different levels of precision, from 4-digit to 8-digit grids, of which also dictate how big the grids are. 4-digit grids are 1x1km, 6-digit grids are 100x100m, etc.
