# The Section

::: warning THIS DOCUMENT IS INCOMPLETE
This document is still being worked on by our staff team
:::

The "section" is the core component of our organisation. Each section is split into teams that work together to achieve a certain objective. Each team in the section may further split themselves into even smaller teams to delegate jobs to specialists. <!-- needs an example! -->

## Typical Infantry Section Structure

[![](/handbook/tiss.png)](/handbook/tiss.png)
