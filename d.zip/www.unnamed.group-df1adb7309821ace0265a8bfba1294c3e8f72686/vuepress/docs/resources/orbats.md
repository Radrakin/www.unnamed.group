# ORBATs

::: danger EXPERIMENTAL CONTENT AHEAD!
Take care when reviewing this document, as it's contents are highly volatile and may completely change at any moment
:::

[[TOC]]

<!--
## Legend

Symbol | Meaning
:- [ ]:|:- [ ]:
`**` | Element Leadership
-->

## Wolfpack (Motorised Infantry)

### Default

- **Section Command Team**
  - [ ] Section Commander
  - [ ] Section Medic
  - [ ] Section Assistant Medic
- **Base of Fire Team**
  - [ ] Team Leader
  - [ ] Autorifleman
  - [ ] Autorifleman/Marksman
  - [ ] Bitch Boy
- **Assault Team**
  - [ ] Team Leader
  - [ ] Grenadier/Pointman
  - [ ] Light AT
  - [ ] Light AT

## Talon (Air Assault Infantry)

### Default

- **Section Command Team**
  - [ ] Section Commander
  - [ ] Section Medic
  - [ ] Fire Support Specialist
  - [ ] Bitch Boy
- **Assault Team Alpha**
  - [ ] Team Leader
  - [ ] Pointman
  - [ ] Light AT
  - [ ] Corpsman
- **Assault Team Bravo**
  - [ ] Team Leader
  - [ ] Pointman
  - [ ] Light AT
  - [ ] Corpsman

## Sabre (Heavy Infantry)

### Default

- **Section Command Team**
  - [ ] Section Commander
  - [ ] Section Medic
  - [ ] Section Assistant Medic
- **Heavy Weapons Team**
  - [ ] Team Leader
  - [ ] Machine Gunner
  - [ ] AT Specialist
  - [ ] Bitch Boy
  - [ ] Bitch Boy
- **Assault Team**
  - [ ] Team Leader
  - [ ] Autorifleman
  - [ ] Grenadier/Pointman
  - [ ] Corpsman
  - [ ] Bitch Boy

## Lightning (Mechanised Assault Infantry)

### Default

- **Section Command Team**
  - [ ] Section Commander
  - [ ] Section Medic
  - [ ] Grenadier
  - [ ] Pointman
  - **Vehicle Crew**
    - [ ] IFV Driver
    - [ ] IFV Gunner
- **Assault Team Alpha**
  - [ ] Team Leader
  - [ ] Grenadier
  - [ ] Pointman
  - [ ] Corpsman
  - **Vehicle Crew**
    - [ ] IFV Driver
    - [ ] IFV Gunner
- **Assault Team Bravo**
  - [ ] Team Leader
  - [ ] Grenadier
  - [ ] Pointman
  - [ ] Corpsman
  - **Vehicle Crew**
    - [ ] IFV Driver
    - [ ] IFV Gunner
